﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace enesblog
{
    public partial class WebForm4 : System.Web.UI.Page
    {
        dataBaseIslemleri dbIslemler = new dataBaseIslemleri();
        protected void Page_Load(object sender, EventArgs e)
        {
            string sqlcumle = "SELECT * FROM(icerikler INNER JOIN icerikfoto ON icerikler.icerikId = icerikfoto.icerikId) WHERE(icerikAktif = 1) LIMIT 1";

            if (Request.QueryString["kId"] != null)
            {
                sqlcumle = "SELECT * FROM(icerikler INNER JOIN icerikfoto ON icerikler.icerikId = icerikfoto.icerikId) WHERE(icerikAktif = 1 AND kategoriId=(SELECT kategoriId FROM kategoriler WHERE kategoriAd='" + Request.QueryString["kId"].ToString() + "')) ";
                lblAranan.Text = Request.QueryString["kId"].ToString();
            }
            else if (Request.QueryString["icId"] != null)
            {

                string icerikSqlcumle = "SELECT * FROM icerikler  WHERE icerikAktif = 1 AND icerikId=" + Request.QueryString["icId"];
           
                panelIcerikler.Visible = false;
                panelIcerkBilgi.Visible = true;
                repeaterTekIcerik.DataSource = dbIslemler.GetDataTable(icerikSqlcumle);
                repeaterTekIcerik.DataBind();

            }
            else if (Request.QueryString["ara"] != null)
            {
                sqlcumle = "SELECT * FROM(icerikler INNER JOIN icerikfoto ON icerikler.icerikId = icerikfoto.icerikId) WHERE(icerikAktif = 1 AND (icerikBaslik LIKE '%" + Request.QueryString["ara"] + "%' OR icerikBilgi LIKE  '%" + Request.QueryString["ara"] + "%'))";
                lblAranan.Text = "' " + Request.QueryString["ara"].ToLower() + " ' İle ilgili Sonuçlar";
                
            }
            else
            {
                sqlcumle = "SELECT * FROM(icerikler INNER JOIN icerikfoto ON icerikler.icerikId = icerikfoto.icerikId) WHERE(icerikAktif = 1)";
            }
            Repeatericerik.DataSource = dbIslemler.GetDataTable(sqlcumle);
            Repeatericerik.DataBind();

            


        }
        public string icerikFotoGetir(int icerikId)
        {
      
            string yol = dbIslemler.getDataCell("SELECT fotoUrl FROM icerikfoto WHERE icerikId = " + icerikId);
            return yol;
        }
    }
}